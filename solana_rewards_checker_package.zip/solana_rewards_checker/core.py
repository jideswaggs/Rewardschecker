import os
import yaml
from .projects.raydium import check_raydium
from .projects.marinade import check_marinade

def run_checker():
    config_path = "config.yaml"
    if not os.path.exists(config_path):
        print("Missing config.yaml")
        return
    with open(config_path, "r") as f:
        config = yaml.safe_load(f)
    address = config["wallet"]["address"]
    private_key = config["wallet"]["private_key"]
    print(f"🔍 Checking for rewards for {address}...")
    check_raydium(address, private_key)
    check_marinade(address, private_key)
