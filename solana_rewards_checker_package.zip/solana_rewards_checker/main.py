from .core import run_checker

def main():
    run_checker()
