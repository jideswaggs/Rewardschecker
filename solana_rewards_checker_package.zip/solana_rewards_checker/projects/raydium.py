def check_raydium(address, private_key):
    print(f"✅ Raydium: 18.43 RAY rewards claimable for {address}")
    if private_key:
        print("🔐 [Signed] Claiming Raydium rewards... [mock tx sent]")
