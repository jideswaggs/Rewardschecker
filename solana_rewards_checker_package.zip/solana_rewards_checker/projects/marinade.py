def check_marinade(address, private_key):
    print(f"✅ Marinade: 2.4 mSOL rewards claimable for {address}")
    if private_key:
        print("🔐 [Signed] Claiming Marinade rewards... [mock tx sent]")
